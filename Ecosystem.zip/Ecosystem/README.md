# Ecosystem Project Iteration 4 - Simple Forest Ecosystem

## Instructions

To run the program, simply open the Forest.exe file or import the Unity package to your assets in the submitted folder. It is not interactive at the moment, so all you have to do is open the file and watch the bees and the bears interact with their environment and each other!